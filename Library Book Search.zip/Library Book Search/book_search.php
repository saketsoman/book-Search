<?php
/** 
*Plugin Name: Library Book Search
*Plugin URI : http://localhost:10004/


*/


   function book_search_post(){
	   
	   register_post_type('book',
	   
	   
	   array(
	   
	   'labels' => array(
	   'name'  => __('books'),
	   'singular_name'  => __('Book'),
	   
 	   ),
	   'public' => true,
	   )
	  );
	   
   }
    
	add_action('init','book_search_post',6);
	



// Add Taxonomoy of Author and Publisher
   
 
//add_filter('author_option', 'books', 6 , 3);  
  
   
function author_option(){
	 
	 register_taxonomy('books','book',$args);
	 
	 $labels = array(
	 'name' => array('Author', 'add author'),
	  'singular_name' =>array('Author', 'author2'),
	   'menu_name' => array('Author', 'author2'),
	   
	   );
}



 
add_action ('init', 'author_option');
 

 

 
function publisher(){
	 
	 register_taxonomy('publisher','books',$args1);
	 
	 $label = array(
	 'name' => array('Publisher', 'add publisher'),

	   );
}

add_action ('init', 'publisher');


function search_book(){
	
	
	 register_post_type('search_books',
	 
	 	   array(
	   
	   'labels' => array(
	   'name'  => __('search_book'),
	   'singular_name'  => __('Book'),	   
	   
 	   ),
	   'public' => true,
	   )
	  );
	   
	
}

add_action('init','search_book');
	
    


?>